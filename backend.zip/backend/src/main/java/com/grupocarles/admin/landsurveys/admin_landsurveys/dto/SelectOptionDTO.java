package com.grupocarles.admin.landsurveys.admin_landsurveys.dto;

public record SelectOptionDTO(String value, String label) {
}
