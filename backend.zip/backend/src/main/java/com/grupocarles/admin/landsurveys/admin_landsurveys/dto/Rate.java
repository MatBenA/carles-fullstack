package com.grupocarles.admin.landsurveys.admin_landsurveys.dto;

public record Rate(
        double value_avg,
        double value_sell,
        double value_buy
) {}