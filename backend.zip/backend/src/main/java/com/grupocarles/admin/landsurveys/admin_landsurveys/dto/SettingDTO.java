package com.grupocarles.admin.landsurveys.admin_landsurveys.dto;

public record SettingDTO (String name, String value) {
}
