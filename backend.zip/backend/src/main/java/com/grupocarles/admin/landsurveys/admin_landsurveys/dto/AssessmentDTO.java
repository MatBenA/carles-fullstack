package com.grupocarles.admin.landsurveys.admin_landsurveys.dto;

public record AssessmentDTO(SelectOptionDTO assessor,
                            Long price,
                            String currency){
}
