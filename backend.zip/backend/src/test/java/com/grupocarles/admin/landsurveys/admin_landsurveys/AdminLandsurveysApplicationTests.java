package com.grupocarles.admin.landsurveys.admin_landsurveys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminLandsurveysApplicationTests {

}
