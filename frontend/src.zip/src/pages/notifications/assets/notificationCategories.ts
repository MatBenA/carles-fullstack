const notifcationCategories = [
    {value: "statisticTopLimit", label: "Bandera inferior vigencia en dias (90 dias)"},
    {value: "statisticBottomLimit", label: "Bandera superior vigencia en dias (180 dias)"},
    {value: "particularValidity", label: "Vigencia propietarios (60 dias)"},
    {value: "agencyValidity", label: "Vigencia inmobiliaria/intermediario (120 dias)"},
    {value: "unworkableValidity", label: "Vigencia rojo no trabajable (365 dias)"},
]

export default notifcationCategories;