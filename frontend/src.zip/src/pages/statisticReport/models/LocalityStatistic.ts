export interface LocalityStatistic {
    locality: string;
    total: number;
}
