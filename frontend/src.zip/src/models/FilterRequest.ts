export interface FilterRequest {
    minPrice: number,
    maxPrice: number,
    businessEvaluation: string
}